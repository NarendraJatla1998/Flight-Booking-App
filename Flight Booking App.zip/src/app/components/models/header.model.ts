export interface HeaderModel {
    filed: string;
    header: string;
    pSortableColumn: string;
}