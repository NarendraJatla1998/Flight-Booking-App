export interface FilterDropDownModel {
    name: string;
}