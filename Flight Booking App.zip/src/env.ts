export default {
    baseURL: 'https://api.npoint.io/378e02e8e732bb1ac55b'
}